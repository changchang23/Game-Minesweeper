#pragma once

using COLOUR = const std::string;

COLOUR red_fg = "\033[1;31m";
COLOUR green_fg = "\033[1;32m";
COLOUR yellow_fg = "\033[1;33m";
COLOUR blue_fg = "\033[1;34m";
COLOUR magenta_fg = "\033[1;35m";
COLOUR cyan_fg = "\033[1;36m";
COLOUR white_fg = "\033[1;37m";
COLOUR blue_bg = "\033[44m";
COLOUR white_bg = "\033[47m";
COLOUR reset = "\033[0m";