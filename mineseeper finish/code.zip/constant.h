#pragma once
#pragma once
#include <iostream>
const std::string WINDOW_TITLE = "Minesweeper!";

const int SCREEN_WIDTH = 889;
const int SCREEN_HEIGHT = 500;
const int TILE_SIZE = 28;


